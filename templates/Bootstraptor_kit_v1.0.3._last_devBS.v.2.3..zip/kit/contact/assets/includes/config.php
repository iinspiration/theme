<?php
// Where will you get the forms' results?
define("WEBMASTER_EMAIL", 'sitedisc@sitediscount.ru');
?>